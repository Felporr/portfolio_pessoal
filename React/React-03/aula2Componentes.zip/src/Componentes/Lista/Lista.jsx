import '../Lista/Lista.css'

function Lista (){

    return (
        <>

        <div className='display3'>
            <img src="src/assets/png-galo.png" alt="" />
        </div>    

        </>
    )

}

export default Lista
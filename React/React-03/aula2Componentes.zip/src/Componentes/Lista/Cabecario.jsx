import '../Lista/Cabecario.css'

function Cabecario (){
    
    return (
        <>
        <div className='display1 '>
            <span className='Cabecario'>
                Galo
            </span>
        </div>
        </>
    )

}

export default Cabecario
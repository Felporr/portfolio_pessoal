import '../Lista/Rodape.css'


function Rodape (){
    
    return (
        <>

            <div className='display2'>
                   <span className='Rodape'>
                        Filipe José Braga Dias - 3b2 - 22201440
                   </span>
            </div>

        </>
    )

}

export default Rodape